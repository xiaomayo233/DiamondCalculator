#include <stdio.h>

struct Position{
	long x;
	long z;
};

struct Position cal(long seed,int cx,int cz);

int main(){
	struct Position m = cal(123,1,2);
	int x = m.x;
	int z = m.z;
	printf("x = %d,z = %d",x,z);
}


struct Position cal(long seed,int cx,int cz){
	long long mul = 25214903917L;
	long long mask = 281474976710655L;
	
	/* 获取i j */
	long long temp = seed ^ mul & mask;
	long long first = ((temp * mul + 11) & mask);
	long long second = ((first * mul + 11) & mask);
	long long third = ((second * mul + 11) & mask);
	long long fourth = ((third * mul + 11) & mask);
	
	first >>= 16;
	first <<= 32;
	
	second <<= 16;
	second >>= 32;
	
	third >>= 16;
	third <<= 32;
	
	fourth <<= 16;
	fourth >>= 32;
	
	long long i = (first + second) | 1;
	long long j = (third + fourth) | 1;
	
	/* 获取坐标 */
	temp =((16 * cx * i + 16 * cz * j) ^ seed) + 60009;
	
	temp = (temp ^ mul) & mask;
	
	first = (temp * mul + 11) & mask;
	second = (first * mul + 11) & mask;
	
	first >>= 44;
	second >>= 44;
	
	long long x = (first + 16 * cx);
	long long z = (second + 16 * cz);
	struct Position ret = {x,z};
	return ret;
}