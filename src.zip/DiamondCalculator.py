def cal(seed,cx,cz):
    mul = 25214903917;
    mask = 281474976710655;
    
    ''' 获取i j '''
    temp = seed ^ mul & mask;
    
    first = ((temp * mul + 11) & mask);
    second = ((first * mul + 11) & mask);
    third = ((second * mul + 11) & mask);
    fourth = ((third * mul + 11) & mask);
    
    first >>= 16;
    first <<= 32;
    
    second <<= 16;
    second >>= 32;
    
    third >>= 16;
    third <<= 32;
    
    fourth <<= 16;
    fourth >>= 32;
    
    i = (first + second) | 1;
    j = (third + fourth) | 1;
    
    ''' 获取坐标 '''
    temp =((16 * cx * i + 16 * cz * j) ^ seed) + 60009;
    
    temp = (temp ^ mul) & mask;
    
    first = (temp * mul + 11) & mask;
    second = (first * mul + 11) & mask;
    
    first >>= 44;
    second >>= 44;
    
    x = (first + 16 * cx);
    z = (second + 16 * cz);
    return {"x": x,"z": z};

print(cal(123,1,2))